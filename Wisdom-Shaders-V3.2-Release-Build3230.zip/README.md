# Wisdom-Shaders
A Minecraft shaderspack. Offers high performance with high quality at the same time.

Requirements&Specifications are on the website.

This shader is in THE APACHE License, more information in LICENSE.TXT

# Official website
https://qionouu.cn/
